#include "codigoAssembly.h"

int Registrador_atual = 7; 

int section_bss = 0; //para variaveis globais e constantes
int section_text_var_glbl = 0; //para var globais
int section_text_func = 0; //para funcoes
int num_var_local = 0;

/*chamada uma vez so na raiz da AST*/

void generateAsm(NODO* arvore){

    FILE *output_file = stdout;

    //printf("1\n"); // debug

    geraCodigoPelaAST(arvore, output_file);

    if (output_file != stdout) 
        fclose(output_file);
}

void geraCodigoPelaAST(NODO* nodo, FILE* output_file){

    if (nodo == NULL) return; 

    if (!nodo || nodo->visitado) return;
    nodo->visitado = 1;

    switch (nodo->valor_lexico->natureza) {
        case LITERAL:
            // Código para um literal
            //geraCodigoExpressao(nodo, output_file);
            //fprintf(output_file, "# Passou LITERAL\n");
            break;

        case GLOBAL_DECL:
            // Código para declarar variaveis globais
            geraCodigoVarGlobal(nodo, output_file);
            //fprintf(output_file, "# Passou GLOBAL_DECL\n");
            break;

        case VARIABLE:
            // Código para declarar uma variavel local (?)
            geraCodigoExpressao(nodo, output_file);
            //geraCodigoVariable(nodo, output_file);
            //fprintf(output_file, "# Passou VARIABLE %s, desl %d\n",nodo->valor_lexico->valor, nodo->valor_lexico->deslocamento);
            break;

        case OPERAND:
            // Código para usar uma variavel em uma expressao
            //geraCodigoOperand(nodo, output_file);
            //fprintf(output_file, "# Passou OPERAND %s, desl %d\n",nodo->valor_lexico->valor, nodo->valor_lexico->deslocamento);
            break;

        case ATRIBUITION:
            // Código para uma atribuição
            geraCodigoAtrib(nodo, output_file);
            //fprintf(output_file, "# Passou ATRIBUITION\n");
            break;

        case OPERATOR:
            // Código para uma função
            geraCodigoOperacao(nodo, output_file);
            //fprintf(output_file, "# Passou OPERATOR\n");
            break;

        case CONTROL:
            // Código para uma função
            geraCodigoControle(nodo, output_file);
            //fprintf(output_file, "# Passou CONTROL\n");
            break;

        case TYPE:
            // Código para um TYPE
            //geraCodigo(nodo, output_file);
            //fprintf(output_file, "# Passou TYPE\n");
            break;

        case RETURN:
            // Código para um RETURN
            geraCodigoRetorno(nodo, output_file);
            //fprintf(output_file, "# Passou RETURN %s\n",nodo->valor_lexico->valor);
            break;

        case FUNCTION_CALL:
            // Código para uma chamada de função
            //geraCodigoChamadaFuncao(nodo, output_file);
            //fprintf(output_file, "# Passou FUNCTION_CALL\n");
            break;

        case FUNCTION:
            // Código para uma função
            geraCodigoFuncao(nodo, output_file);
            //fprintf(output_file, "# Passou FUNCTION\n");
            break;

        default:
            //fprintf(output_file, "# Passou default\n");
            break;
    }

    // Percorre toda a arvore
    geraCodigoPelaAST(nodo->filho, output_file);
    geraCodigoPelaAST(nodo->irmao, output_file);

}

void geraCodigoVarGlobal(NODO* nodo, FILE* output_file){
    //Inicia a declaracao de Var Globais
    if(section_text_var_glbl == 0)
        {
        fprintf(output_file, "\t.text\n");
        section_text_var_glbl = 1;
        }

    fprintf(output_file, "\t.globl\t%s\n",nodo->valor_lexico->valor); 

    if(section_bss == 0)
        {
        fprintf(output_file, "\t.bss\n");
        section_bss = 1;
        }

    fprintf(output_file, "\t.align 4\n");
    fprintf(output_file, "\t.type\tz, @object\n");
    fprintf(output_file, "\t.size\t%s, 4\n",nodo->valor_lexico->valor);
    fprintf(output_file, "%s:\n",nodo->valor_lexico->valor);
    fprintf(output_file, "\t.zero	4\n");
}

void geraCodigoVariable(NODO* nodo, FILE* output_file){
    // acho que so precisa definir o deslocamento dela (posicao da pilha)
    num_var_local ++;
    nodo->valor_lexico->deslocamento = num_var_local * -4;
    //fprintf(output_file, "%d",nodo->valor_lexico->valor);
}

void geraCodigoAtrib(NODO* nodo, FILE *output_file) {
    // nodo->filho eh o =
    // nodo->filho->irmao eh o OPERAND
    // nodo->filho->irmao->irmao e a expressao

    if(nodo->filho == NULL|| nodo->filho->irmao == NULL || nodo->filho->irmao->irmao == NULL)
    {}
        else
    if (nodo->filho->irmao->irmao->valor_lexico->natureza == LITERAL){
        fprintf(output_file, "\tmovl\t$%s, %d(%%rbp)\n",nodo->filho->irmao->irmao->valor_lexico->valor 
                                                       ,nodo->filho->irmao->valor_lexico->deslocamento);
    }
    else if (nodo->filho->irmao->irmao->valor_lexico->natureza == OPERAND) {
            fprintf(output_file, "\tmovl\t%d(%%rbp), %%eax\n",nodo->filho->irmao->irmao->valor_lexico->deslocamento);
            fprintf(output_file, "\tmovl\t%%eax, %s(%%rip)\n",nodo->filho->irmao->valor_lexico->valor);
        }
    
    //geraCodigoExpressao(nodo->irmao, output_file);

}

void geraCodigoOperacao(NODO* arvore, FILE *output_file){
    //fprintf(output_file,"\tentrou geraCodigoOperacao\n");
    if (arvore == NULL) return;
    // Gera código para o operando esquerdo
    geraCodigoExpressao(arvore->filho, output_file);
    
    //fprintf(output_file,"\tempira resultado no reg\n");
    // Empilha o resultado da operação no registrador
    fprintf(output_file, "\tpush %%eax\n");

    // Gera código para o operando direito
    geraCodigoExpressao(arvore->filho->irmao, output_file);

    // Desempilha e realiza a operação
    fprintf(output_file, "\tpop %%ecx\n");

    switch (arvore->valor_lexico->valor[0]) {
        case '+':
            fprintf(output_file, "\taddl %%ecx, %%eax\n");
            break;
        case '-':
            fprintf(output_file, "\tsubl %%ecx, %%eax\n");
            break;
        case '*':
            fprintf(output_file, "\timull %%ecx, %%eax\n");
            break;
        case '/':
            fprintf(output_file, "\tcltd\n");
            fprintf(output_file, "\tidivl %%ecx\n");
            break;
    }
}

void geraCodigoControle(NODO* arvore, FILE *output_file){
    static int label_counter = 0;
    int local_label = label_counter++;

    if (strcmp(arvore->valor_lexico->valor, "if") == 0) {
        geraCodigoExpressao(arvore->filho, output_file);
        fprintf(output_file, "\tcmp $0, %%eax\n");
        fprintf(output_file, "\tje .L%d\n", local_label);
        geraCodigoPelaAST(arvore->filho->irmao, output_file); // bloco 'then'
        fprintf(output_file, ".L%d:\n", local_label);
    } else if (strcmp(arvore->valor_lexico->valor, "while") == 0) {
        int start_label = label_counter++;
        int end_label = label_counter++;
        fprintf(output_file, ".L%d:\n", start_label);
        geraCodigoExpressao(arvore->filho, output_file);
        fprintf(output_file, "\tcmp $0, %%eax\n");
        fprintf(output_file, "\tje .L%d\n", end_label);
        geraCodigoPelaAST(arvore->filho->irmao, output_file); // bloco 'while'
        fprintf(output_file, "\tjmp .L%d\n", start_label);
        fprintf(output_file, ".L%d:\n", end_label);
    }
}

void geraCodigoRetorno(NODO* nodo, FILE *output_file){
    //fprintf(output_file, "\n# CODIGO DO RETURN\n");
    //printNodos(nodo, output_file);
    if(nodo->filho == NULL)
        {//fprintf(output_file, "# Passou RETURN %s, mas filho e NULL\n",nodo->valor_lexico->valor);
        }
        else
    if (nodo->filho->valor_lexico->natureza == OPERAND)
        fprintf(output_file, "\tmovl\t%d(%%rbp), %%eax\n",nodo->filho->valor_lexico->deslocamento);
    else if (nodo->filho->valor_lexico->natureza == LITERAL)
            fprintf(output_file, "\tmovl\t$%s, %%eax\n",nodo->filho->valor_lexico->valor);
    fprintf(output_file, "\tmovq\t%%rbp, %%rsp\n");
    fprintf(output_file, "\tpopq\t%%rbp\n");
    fprintf(output_file, "\tret\n");
}

void geraCodigoChamadaFuncao(NODO* arvore, FILE *output_file) {
    // arvore->filho é a função
    // arvore->irmao é a lista de argumentos
    for (NODO* arg = arvore->irmao; arg != NULL; arg = arg->irmao) {
        geraCodigoPelaAST(arg, output_file);
        fprintf(output_file, "\tpush %%eax\n");
    }
    fprintf(output_file, "\tcall %s\n", arvore->filho->valor_lexico->valor);
    fprintf(output_file, "\tadd $%d, %%esp\n", 4 * contador_de_argumentos(arvore->irmao)); // Limpa a pilha
}

void geraCodigoFuncao(NODO* nodo, FILE *output_file) {
    //Inicia a declaracao da funcao
    if(section_text_func == 0)
        {
        fprintf(output_file, "\t.text\n");
        section_text_func = 1;
        }
    fprintf(output_file, "\t.globl %s\n", nodo->valor_lexico->valor);
    fprintf(output_file, "\t.type %s, @function\n", nodo->valor_lexico->valor);

    fprintf(output_file, "%s:\n", nodo->valor_lexico->valor);
    fprintf(output_file, ".LFB0:\n");
    fprintf(output_file, "\tpushq \t%%rbp\n");
    fprintf(output_file, "\tmovq \t%%rsp, %%rbp\n");
    fprintf(output_file, "\tsubq \t$%d, %%rsp\n", 10 * 4); // Assumindo 4 bytes por variável e no max 10 variaveis
}

void geraCodigoExpressao(NODO *nodo, FILE *output_file) {
    //fprintf(output_file, "\tarvore->valor_lexico->natureza %d \n", arvore->valor_lexico->natureza);
    if (nodo == NULL) return;

    if (nodo->valor_lexico->natureza == VARIABLE) {
        num_var_local ++;
        nodo->valor_lexico->deslocamento = num_var_local * -4;
        fprintf(output_file, "\tmovl %s(%%rip), %%eax \n", nodo->valor_lexico->valor);
    } else if (nodo->valor_lexico->natureza == OPERAND) {
        fprintf(output_file, "\tmovl %d(%%rip), %%eax \n", nodo->valor_lexico->deslocamento);
    } else if (nodo->valor_lexico->natureza == LITERAL) {
        fprintf(output_file, "\tmovl $%s, %%eax \n", nodo->valor_lexico->valor);
    //fprintf(output_file, "\n# CODIGO DA EXPRESSAO\n");
    //printNodos(nodo, output_file);
    }
}


/*Seleciona o proximo registrador*/
int selecionaRegistrador (int Registrador_atual){
    // algoritmo bobinho por enquanto
    Registrador_atual ++;
    if (Registrador_atual > 15)
        Registrador_atual = 8;
    
    return Registrador_atual;
}

// Função auxiliar para contar os argumentos de uma função
int contador_de_argumentos(NODO* nodo) {
    int count = 0;
    for (NODO* arg = nodo; arg != NULL; arg = arg->irmao) {
        count++;
    }
    return count;
}

//Funcao para debugar
void printNodos(NODO *nodo, FILE *output_file){
    fprintf(output_file, "\n# PRINT NODO \nvalor: %s\nnatureza: %d\ntipo: %d\ndeslocamento: %d\n\n", 
                                                nodo->filho->valor_lexico->valor, 
                                                nodo->filho->valor_lexico->natureza,
                                                nodo->filho->valor_lexico->tipo,
                                                nodo->filho->valor_lexico->deslocamento);
}