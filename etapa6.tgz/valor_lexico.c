#include "valor_lexico.h"

VALOR_LEXICO* createValorLexico(char* valor, int natureza, int tipo, int num_linha)
{
    VALOR_LEXICO* valor_lexico = (VALOR_LEXICO*) malloc(sizeof(VALOR_LEXICO));;
    valor_lexico->num_linha = num_linha;
    valor_lexico->natureza = natureza;
    valor_lexico->tipo = tipo;
    valor_lexico->deslocamento = 0;
    valor_lexico->valor = strdup(valor);

    return valor_lexico;
}

void freeValorLexico(VALOR_LEXICO* valor_lexico)
{
    if (valor_lexico == NULL) 
        return;
        
    free(valor_lexico->valor);
    free(valor_lexico);
}